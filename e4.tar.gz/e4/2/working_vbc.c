//This file is given at the exam

#include <stdio.h>
#include <malloc.h>
#include <ctype.h>

typedef struct node {
    enum {
        ADD,
        MULTI,
        VAL
    }   type;
    int val;
    struct node *l;
    struct node *r;
}   node;

node    *new_node(node n)
{
    node *ret = calloc(1, sizeof(n));
    if (!ret)
        return (NULL);
    *ret = n;
    return (ret);
}

void    destroy_tree(node *n)
{
    if (!n)
        return ;
    if (n->type != VAL)
    {
        destroy_tree(n->l);
        destroy_tree(n->r);
    }
    free(n);
}

void    unexpected(char c)
{
    if (c)
        printf("Unexpected token '%c'\n", c);
    else
        printf("Unexpected end of file\n");
}

int accept(char **s, char c)
{
    if (**s)
    {
        (*s)++;
        return (1);
    }
    return (0);
}

int expect(char **s, char c)
{
    if (accept(s, c))
        return (1);
    unexpected(**s);
    return (0);
}

node    *parse_expr(char **s);

node    *parse_number(char **s)
{
    if (!**s || !isdigit(**s))
    {
        unexpected(**s);
        return NULL;
    }
    node tmp = {.type = VAL, .val = **s - '0', .l = NULL, .r = NULL};
    (*s)++;
    return new_node(tmp);
}

node    *parse_factor(char **s)
{
    if (**s == '(')
    {
        (*s)++;
        node *n = parse_expr(s);
        if (!n || !expect(s, ')'))
        {
            destroy_tree(n);
            return NULL;
        }
        return n;
    }
    return parse_number(s);
}

node    *parse_term(char **s)
{
    node *l = parse_factor(s);
    if (!l)
        return NULL;
    while (**s == '*')
    {
        (*s)++;
        node *r = parse_factor(s);
        if (!r)
        {
            destroy_tree(l);
            return NULL;
        }
        node tmp = {.type = MULTI, .l = l, .r = r};
        l = new_node(tmp);
    }
    return l;
}

node    *parse_expr(char **s)
{
    node *l = parse_term(s);
    if (!l)
        return NULL;
    while (**s == '+')
    {
        (*s)++;
        node *r = parse_term(s);
        if (!r)
        {
            destroy_tree(l);
            return NULL;
        }
        node tmp = {.type = ADD, .l = l, .r = r};
        l = new_node(tmp);
    }
    return l;
}

int eval_tree(node *tree)
{
    switch (tree->type)
    {
        case ADD:
            return (eval_tree(tree->l) + eval_tree(tree->r));
        case MULTI:
            return (eval_tree(tree->l) * eval_tree(tree->r));
        case VAL:
            return (tree->val);
    }
}

int scotch_numbers(char *argv)
{
    int i = 0;

    while (argv[i] && argv[i + 1])
    {
        if (isdigit(argv[i] && isdigit(argv[i + 1])))
        {
            unexpected(argv[i + 1]);
            return (-1);
        }
        ++i;
    }
    return (1);
}

int scotch_parenthesis(char *argv)
{
    int i = 0;
    int open = 0;
    int close = 0;

    while (argv[i])
    {
        if (argv[i] == '(')
            open++;
        else if (argv[i] == ')')
            close++;
        ++i;
    }
    if (close > open)
    {
        unexpected(')');
        return (-1);
    }
    else if (open > close)
    {
        unexpected('(');
        return (-1);
    }
    return (1);
}

int main(int argc, char **argv)
{
    if (argc != 2)
        return (1);
    if (scotch_numbers(argv[1]) == -1)
        return (1);
    if (scotch_parenthesis(argv[1]) == -1)
        return (1);
    node *tree = parse_expr(&argv[1]);
    if (!tree)
        return (1);
    printf("%d\n", eval_tree(tree));
    destroy_tree(tree);
}