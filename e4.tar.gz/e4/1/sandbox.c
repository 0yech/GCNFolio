/*
Assignment name		:	sandbox
Expected files		:	sandbox.c
Allowed functions	:	fork, waitpid, exit, alarm, sigaction, kill,
						printf, strsignal, errno
===============================================================================

Write the following function:

#include <stdbool.h>
int	sandbox(void (*f)(void), unsigned int timeout, bool verbose)

This function must test if the function f is a nice function or a bad function,
you will return 1 if f is nice , 0 if f is bad or -1 in case of an error in
your function.

A function is considered bad if it is terminated or stopped by a signal
(segfault, abort...), if it exit with any other exit code than 0 or if it
times out.

If verbose is true, you must write the appropriate message among the following:

"Nice function!\n"
"Bad function: exited with code <exit_code>\n"
"Bad function: <signal description>\n"
"Bad function: timed out after <timeout> seconds\n"

You must not leak processes (even in zombie state, this will be checked using
wait).

We will test your code with very bad functions.
*/
#include <stdbool.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <errno.h>
#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <stdlib.h>

void do_nothing(int sig)
{
	(void)sig;
}

int sandbox(void (*f)(void), unsigned int timeout, bool verbose)
{
    pid_t pid = fork();

    if (pid == -1)
        return (-1);

    if (pid == 0)
    {
        // Kill process if it takes longer than "timeout"
        alarm(timeout);
        f();
        exit(0);
    }
    struct sigaction sa;
    sa.sa_handler = do_nothing;
    sa.sa_flags = 0;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGALRM, &sa, NULL);
    // Avoid getting blocked in the parent with alarm too
    alarm(timeout);

    int st;
    int r = waitpid(pid, &st, 0); // Wait til child finishes
    if (r == -1)
    {
        // waitpid failed, check if errno returned INTERRUPT
        if (errno == EINTR)
        {
            kill(pid, SIGKILL);
            // Avoid zombie process
            waitpid(pid, NULL, 0);
            if (verbose)
                printf("Bad function: timed out after %d seconds\n", timeout);
            return (0);
        }
        return (-1);
    }
    if (WIFEXITED(st))
    {
        int ex_code = WEXITSTATUS(st);
        if (ex_code == 0)
        {
            if (verbose)
                printf("Nice function!\n");
            return (1);
        }
        if (verbose)
            printf("Bad function: exited with code %d\n", ex_code);
        return (0);
    }
    if (WIFSIGNALED(st))
    {
        if (WTERMSIG(st) == SIGALRM)
        {
            if (verbose)
                printf("Bad function: timed out after %d seconds\n", timeout);
            return (0);
        }
        if (verbose)
            printf("Bad function: %s\n", strsignal(WTERMSIG(st)));
        return (0);
    }
    return (-1);
}

// Tests under

void ok_f(void)
{
	printf("hapi");
}

void inf_f(void)
{
	while (1)
		;
}

void bad_exit(void)
{
	exit(41);
}

void cancel_alarm(void)
{
	struct sigaction ca;
	ca.sa_handler = SIG_IGN;
	sigaction(SIGALRM, &ca, NULL);

	sleep(5);
	printf("f waited 5 seconds, should be terminated before by alarm set in parent process if timeout < 5\n");
}

void leak_f(void)
{
	int *p = NULL;
	*p = 4;
}

int main(void)
{
	sandbox(bad_exit, 3, true);
	sandbox(inf_f, 2, true);
	sandbox(cancel_alarm, 3, true);
}