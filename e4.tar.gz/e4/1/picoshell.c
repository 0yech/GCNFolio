
/*

/!\ IMPORTANT, THE SUBJECT HAS CHANGED MULTIPLE TIMES.

I used this to train it, but it seems it must return 0 no matter if it fails.
It should now return 1 if pipe, dup2 or fork fails. So this won't work as is
in the exam, but you can surely train and make it work :3

Allowed functions:
pipe, fork, dup2, execvp, close, exit, wait

Write the following function:

	int picoshell(char **cmds[])

It has to simulate the pipe. cmds[i] contains the command with its arguments.
Use execvp(cmds[i][0], cmds) to execute a command.
It has to return 1, if a command fail. Do not leak file descriptors.
In the exam, a main file will be given to test your picoshell
*/

#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>

// Pipe and dup2 handle Fds in a smart way, they will use the earliest
// available fd, meaning doing this abomination will only cost 1 fd per call.

static int fakeassdup(int oldfd)
{
    int p[2];
    if (pipe(p) == -1)
        return -1;
    if (dup2(oldfd, p[0]) == -1)
	{
        close(p[0]);
        close(p[1]);
        return -1;
    }
    close(p[1]);
    return p[0];
}

// recursive woohoo

void piping(char ***cmds, int index, int *res, int saved_stdin, int saved_stdout)
{
	int fd[2];

	pipe(fd);
    // If the command has a "next" command, STDOUT redirected to write-end pipe
	if (cmds[index + 1])
		dup2(fd[1], STDOUT_FILENO);
	if (fork() == 0)
	{
		close(fd[0]);
		close(fd[1]);
		close(saved_stdin);
		close(saved_stdout);
        // Rember the name of the command itself is part of its args,
        // so calling cmds/args like this is the way. execvp(ls, {ls, -l, -a})
		execvp(cmds[index][0], cmds[index]);
		exit(1);
	}
    // STDIN goes to read-end pipe for the next command
	dup2(fd[0], STDIN_FILENO);
    // Restore STDOUT, the dup2 earlier will handle stdout if there's a "next" command.
	dup2(saved_stdout, STDOUT_FILENO);
	close(fd[0]);
	close(fd[1]);
	if (cmds[index + 1] == NULL)
	{
        // Put terminal back to STDIN when no more commands are left
		dup2(saved_stdin, STDIN_FILENO);
		int status;
        // Wait for the kids
		while (wait(&status) != -1)
		{
            // deprecated i guess, would check if the command failed
			if (WIFEXITED(status) && WEXITSTATUS(status) != 0)
                *res = 1;
		}
		return ;
	}
	piping(cmds, index + 1, res, saved_stdin, saved_stdout);
}

int picoshell(char **cmds[])
{
	int saved_stdin = fakeassdup(STDIN_FILENO);
	int saved_stdout = fakeassdup(STDOUT_FILENO);
	int res = 0;

	piping(cmds, 0, &res, saved_stdin, saved_stdout);

	close(saved_stdin);
	close(saved_stdout);

	return (res);
}

int main(void)
{
	char **cmds[4];
	static char *cmd1[] = {"ls", NULL};
    static char *cmd2[] = {"grep", "xxxxxxxxxx", NULL};
    static char *cmd3[] = {"wc", NULL};

    cmds[0] = cmd1;
    cmds[1] = cmd2;
    cmds[2] = cmd3;
    cmds[3] = NULL;
	
	int res = picoshell(cmds);
	if (res)
		write(1, "Returned 1\n", 11);
	return (0);
} 